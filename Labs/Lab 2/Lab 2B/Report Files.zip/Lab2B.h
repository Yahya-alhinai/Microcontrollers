/* 
 * File:   wongx654_lab2b_asmLib_v001.h
 * Author: MrAwe
 *
 * Created on February 6, 2018, 8:42 AM
 */

#ifndef WONGX654_LAB2B_ASMLIB_V001_H
#define	WONGX654_LAB2B_ASMLIB_V001_H

#ifdef	__cplusplus
extern "C" {
#endif
void acw_wait_50us(void);
void write_0(void);
void write_1(void);
void wait_1ms(void);



#ifdef	__cplusplus
}
#endif

#endif	/* WONGX654_LAB2B_ASMLIB_V001_H */

