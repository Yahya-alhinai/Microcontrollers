/* 
 * File:   Lab05_header.h
 * Author: yahya
 *
 * Created on March 31, 2018, 11:37 PM
 */

#ifndef LAB05_HEADER_H
#define	LAB05_HEADER_H

#ifdef	__cplusplus
extern "C" {
#endif

    
void wait(int number);
void lcd_cmd(char Package);
void lcd_setCursor(int x, int y);
void lcd_init();
void lcd_printChar(char Package);
void lcd_printStr(const char *s);
void setup(void);


#ifdef	__cplusplus
}
#endif

#endif	/* LAB05_HEADER_H */

